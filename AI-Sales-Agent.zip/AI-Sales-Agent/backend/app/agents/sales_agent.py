"""
Sales agent: pricing, quotations, upsell/cross-sell.
Grounds its answer in the product catalog via a lightweight DB lookup
before generating a response, so it doesn't hallucinate prices.
"""
from app.agents.state import AgentState
from app.services.llm_service import get_chat_model
from app.services.product_service import search_products_by_keyword

SYSTEM_PROMPT = """You are a friendly, knowledgeable sales assistant for an e-commerce company.
Use the product catalog data provided to answer accurately — never invent prices, SKUs, or stock levels.
When relevant, suggest one complementary upsell or cross-sell product from the catalog data.
Keep responses concise, warm, and helpful. Use markdown for prices and product names (bold).
If no catalog data is relevant, answer generally and offer to check specific products."""


async def sales_agent_node(state: AgentState) -> AgentState:
    message = state["user_message"]
    catalog_matches = await search_products_by_keyword(message, limit=5)

    catalog_context = "\n".join(
        f"- {p.name} ({p.category}): ${p.price:.2f}, stock: {p.stock}, rating: {p.rating}/5"
        for p in catalog_matches
    ) or "No exact catalog matches found."

    llm = get_chat_model(temperature=0.4)
    prompt = (
        f"{SYSTEM_PROMPT}\n\nRelevant catalog data:\n{catalog_context}\n\n"
        f"Customer message: {message}"
    )
    result = await llm.ainvoke(prompt)

    state["response"] = result.content
    state["agent_used"] = "sales_agent"
    state["sources"] = []
    return state
