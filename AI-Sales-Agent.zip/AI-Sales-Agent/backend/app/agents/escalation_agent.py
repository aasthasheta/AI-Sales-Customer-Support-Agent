"""
Escalation agent: triggered on low routing confidence or detected anger.
Creates a support ticket and gives the user a calm, reassuring response.
"""
from app.agents.state import AgentState
from app.services.ticket_service import create_ticket_for_user


async def escalation_agent_node(state: AgentState) -> AgentState:
    reason = "low_confidence" if state.get("confidence", 1.0) < 0.55 else "angry_user_detected"

    await create_ticket_for_user(
        user_id=state.get("user_id"),
        subject="Escalated conversation",
        description=state["user_message"],
        reason=reason,
    )

    state["response"] = (
        "I want to make sure you get the right help here — I've escalated this to our human "
        "support team and created a ticket for you. Someone will follow up shortly. "
        "Is there anything else I can help clarify in the meantime?"
    )
    state["agent_used"] = "escalation_agent"
    state["escalated"] = True
    state["escalation_reason"] = reason
    state["sources"] = []
    return state
