"""
Support agent: FAQs, returns, warranty, refunds, troubleshooting.
"""
from app.agents.state import AgentState
from app.services.llm_service import get_chat_model

SYSTEM_PROMPT = """You are a patient, clear customer support agent.
Help with FAQs, returns, warranty, refunds, and troubleshooting.
Standard policies (use these unless the user's history says otherwise):
- Returns: accepted within 30 days of delivery, item must be unused/original packaging.
- Warranty: 12 months manufacturer defect coverage from delivery date.
- Refunds: processed within 5-7 business days to the original payment method after the return is received.
Be empathetic. If the issue seems complex or you're not fully confident in the answer,
say so plainly rather than guessing."""


async def support_agent_node(state: AgentState) -> AgentState:
    message = state["user_message"]
    llm = get_chat_model(temperature=0.3)
    prompt = f"{SYSTEM_PROMPT}\n\nCustomer message: {message}"
    result = await llm.ainvoke(prompt)

    state["response"] = result.content
    state["agent_used"] = "support_agent"
    state["sources"] = []
    return state
