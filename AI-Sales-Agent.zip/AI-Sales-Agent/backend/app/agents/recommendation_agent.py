"""
Recommendation agent: semantic product search + personalized suggestions.
"""
from app.agents.state import AgentState
from app.services.llm_service import get_chat_model
from app.services.recommendation_service import semantic_product_search

SYSTEM_PROMPT = """You are a product discovery assistant. Given the customer's request and a
shortlist of semantically matched products, recommend the best 1-3 options and briefly explain
why each fits their need. Be concise. Use markdown bold for product names."""


async def recommendation_agent_node(state: AgentState) -> AgentState:
    message = state["user_message"]
    matches = await semantic_product_search(message, top_k=6)

    if not matches:
        state["response"] = (
            "I couldn't find matching products right now. Could you tell me a bit more about "
            "what you're looking for — category, budget, or use case?"
        )
        state["agent_used"] = "recommendation_agent"
        state["sources"] = []
        return state

    catalog_context = "\n".join(
        f"- {p.name} ({p.category}): ${p.price:.2f}, rating {p.rating}/5 — {p.description[:120]}"
        for p in matches
    )

    llm = get_chat_model(temperature=0.4)
    prompt = f"{SYSTEM_PROMPT}\n\nCandidate products:\n{catalog_context}\n\nCustomer request: {message}"
    result = await llm.ainvoke(prompt)

    state["response"] = result.content
    state["agent_used"] = "recommendation_agent"
    state["sources"] = []
    return state
