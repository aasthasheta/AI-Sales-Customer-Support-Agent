"""
RAG agent: retrieves relevant chunks from ChromaDB and generates
a cited answer grounded in the company's uploaded documents.
"""
from app.agents.state import AgentState
from app.rag.retriever import retrieve_relevant_chunks
from app.services.llm_service import get_chat_model

SYSTEM_PROMPT = """You are a document-grounded assistant. Answer the user's question using ONLY
the provided context chunks from company documents. If the context doesn't contain
the answer, say you don't have that information in the available documents — do not guess.
Cite which source each fact comes from using [Source: filename] inline."""


async def rag_agent_node(state: AgentState) -> AgentState:
    message = state["user_message"]
    chunks = await retrieve_relevant_chunks(message, top_k=4)

    if not chunks:
        state["response"] = (
            "I couldn't find anything relevant in the uploaded company documents for that question. "
            "Could you rephrase, or would you like me to connect you with support?"
        )
        state["agent_used"] = "rag_agent"
        state["sources"] = []
        return state

    context = "\n\n".join(
        f"[Source: {c['document_name']}]\n{c['text']}" for c in chunks
    )

    llm = get_chat_model(temperature=0.2)
    prompt = f"{SYSTEM_PROMPT}\n\nContext:\n{context}\n\nQuestion: {message}"
    result = await llm.ainvoke(prompt)

    state["response"] = result.content
    state["agent_used"] = "rag_agent"
    state["sources"] = [
        {
            "document_name": c["document_name"],
            "chunk_text": c["text"][:200],
            "relevance_score": c["score"],
        }
        for c in chunks
    ]
    return state
