"""
Order tracking agent: extracts an order number from the message
(or asks for one) and looks it up against the orders table.
"""
import re

from app.agents.state import AgentState
from app.services.order_service import get_order_by_number

ORDER_NUMBER_PATTERN = re.compile(r"\b(ORD-[A-Z0-9]{6,12})\b", re.IGNORECASE)


async def order_tracking_agent_node(state: AgentState) -> AgentState:
    message = state["user_message"]
    match = ORDER_NUMBER_PATTERN.search(message)

    if not match:
        state["response"] = (
            "I'd be happy to check your order status! Could you share your order number? "
            "It looks like `ORD-XXXXXX` and can be found in your confirmation email."
        )
        state["agent_used"] = "order_tracking_agent"
        state["sources"] = []
        return state

    order_number = match.group(1).upper()
    order = await get_order_by_number(order_number)

    if order is None:
        state["response"] = f"I couldn't find an order with the number **{order_number}**. Could you double-check it?"
    else:
        state["response"] = (
            f"Here's the status of order **{order.order_number}**:\n\n"
            f"- **Product:** {order.product_name} (x{order.quantity})\n"
            f"- **Status:** {order.status.value.replace('_', ' ').title()}\n"
            f"- **Tracking number:** {order.tracking_number or 'Not yet assigned'}\n"
            f"- **Estimated delivery:** {order.estimated_delivery.strftime('%b %d, %Y') if order.estimated_delivery else 'TBD'}\n"
            f"- **Total:** ${order.total_amount:.2f}"
        )

    state["agent_used"] = "order_tracking_agent"
    state["sources"] = []
    return state
