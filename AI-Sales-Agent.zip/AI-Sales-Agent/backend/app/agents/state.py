"""
Shared state passed between nodes in the LangGraph multi-agent graph.
"""
from typing import Any, TypedDict


class AgentState(TypedDict, total=False):
    # Input
    user_message: str
    user_id: str
    conversation_history: list[dict[str, str]]  # [{"role": "user"/"assistant", "content": "..."}]

    # Routing
    route: str  # "sales" | "support" | "rag" | "recommendation" | "order_tracking" | "escalation"
    confidence: float

    # Output
    response: str
    agent_used: str
    sources: list[dict[str, Any]]
    escalated: bool
    escalation_reason: str | None
