"""
Supervisor node: classifies the incoming message and decides which
specialist agent should handle it. Uses a structured LLM call with
a constrained output so routing is deterministic and parseable.
"""
import json
import re

from app.agents.state import AgentState
from app.services.llm_service import get_chat_model

ROUTES = ["sales", "support", "rag", "recommendation", "order_tracking", "escalation"]

ROUTER_SYSTEM_PROMPT = f"""You are a routing supervisor for a customer service AI system.
Classify the user's message into exactly one of these categories: {", ".join(ROUTES)}.

- sales: pricing questions, upsell/cross-sell opportunities, quotations, product comparisons for purchase intent
- support: FAQs, returns policy, warranty, refunds, troubleshooting, how-to questions
- rag: questions that require searching uploaded company documents (manuals, policies, specs)
- recommendation: "what should I buy", "similar to X", personalized product discovery
- order_tracking: order status, shipping, cancellation, "where is my order"
- escalation: the user is angry, frustrated, threatening to leave, or explicitly asks for a human

Respond ONLY with strict JSON: {{"route": "<one_of_the_categories>", "confidence": <float 0-1>}}
No prose, no markdown fences.
"""


def _parse_router_output(text: str) -> tuple[str, float]:
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        return "support", 0.3
    try:
        data = json.loads(match.group(0))
        route = data.get("route", "support")
        confidence = float(data.get("confidence", 0.5))
        if route not in ROUTES:
            route = "support"
        return route, confidence
    except (json.JSONDecodeError, ValueError, TypeError):
        return "support", 0.3


ANGER_KEYWORDS = {
    "furious", "angry", "unacceptable", "terrible", "worst", "scam",
    "lawsuit", "sue", "disgusted", "ridiculous", "outrageous", "human agent",
    "talk to a person", "speak to a manager", "real person",
}


async def supervisor_node(state: AgentState) -> AgentState:
    message = state["user_message"]
    lowered = message.lower()

    # Fast-path: obvious anger/human-request signals skip the LLM call entirely.
    if any(keyword in lowered for keyword in ANGER_KEYWORDS):
        state["route"] = "escalation"
        state["confidence"] = 0.95
        return state

    llm = get_chat_model(temperature=0.0)
    history_snippet = "\n".join(
        f"{turn['role']}: {turn['content']}" for turn in state.get("conversation_history", [])[-4:]
    )

    prompt = f"{ROUTER_SYSTEM_PROMPT}\n\nRecent conversation:\n{history_snippet}\n\nUser message: {message}"
    result = await llm.ainvoke(prompt)
    route, confidence = _parse_router_output(result.content)

    state["route"] = route
    state["confidence"] = confidence
    return state


def route_decision(state: AgentState) -> str:
    """Conditional edge function used by the LangGraph graph builder."""
    from app.core.config import settings

    if state.get("confidence", 1.0) < settings.ESCALATION_CONFIDENCE_THRESHOLD:
        return "escalation"
    return state["route"]
