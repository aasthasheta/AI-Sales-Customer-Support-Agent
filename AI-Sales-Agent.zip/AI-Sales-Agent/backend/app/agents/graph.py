"""
Assembles the full multi-agent LangGraph:

              +---------------+
   entry ---> |  supervisor   |
              +-------+-------+
                      |
        route_decision (conditional edge)
                      |
   +----------+----------+-----------+--------------+-------------+
   |          |          |           |              |             |
 sales     support      rag   recommendation  order_tracking  escalation
   |          |          |           |              |             |
   +----------+----------+-----------+--------------+-------------+
                      |
                     END
"""
from langgraph.graph import END, StateGraph

from app.agents.escalation_agent import escalation_agent_node
from app.agents.order_tracking_agent import order_tracking_agent_node
from app.agents.rag_agent import rag_agent_node
from app.agents.recommendation_agent import recommendation_agent_node
from app.agents.sales_agent import sales_agent_node
from app.agents.state import AgentState
from app.agents.supervisor import route_decision, supervisor_node
from app.agents.support_agent import support_agent_node


def build_agent_graph():
    graph = StateGraph(AgentState)

    graph.add_node("supervisor", supervisor_node)
    graph.add_node("sales", sales_agent_node)
    graph.add_node("support", support_agent_node)
    graph.add_node("rag", rag_agent_node)
    graph.add_node("recommendation", recommendation_agent_node)
    graph.add_node("order_tracking", order_tracking_agent_node)
    graph.add_node("escalation", escalation_agent_node)

    graph.set_entry_point("supervisor")

    graph.add_conditional_edges(
        "supervisor",
        route_decision,
        {
            "sales": "sales",
            "support": "support",
            "rag": "rag",
            "recommendation": "recommendation",
            "order_tracking": "order_tracking",
            "escalation": "escalation",
        },
    )

    for node_name in ["sales", "support", "rag", "recommendation", "order_tracking", "escalation"]:
        graph.add_edge(node_name, END)

    return graph.compile()


# Compiled once at import time; reused across requests.
agent_graph = build_agent_graph()
