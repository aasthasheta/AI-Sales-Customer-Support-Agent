from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)


def test_hash_password_produces_different_hash_each_time():
    h1 = hash_password("mypassword")
    h2 = hash_password("mypassword")
    assert h1 != h2  # salted


def test_verify_password_correct():
    hashed = hash_password("correct-horse-battery-staple")
    assert verify_password("correct-horse-battery-staple", hashed) is True


def test_verify_password_incorrect():
    hashed = hash_password("correct-horse-battery-staple")
    assert verify_password("wrong-password", hashed) is False


def test_verify_password_handles_malformed_hash_gracefully():
    assert verify_password("anything", "not-a-real-hash") is False


def test_access_token_round_trip():
    token = create_access_token("user-123", {"email": "test@example.com"})
    payload = decode_token(token)
    assert payload is not None
    assert payload["sub"] == "user-123"
    assert payload["type"] == "access"
    assert payload["email"] == "test@example.com"


def test_refresh_token_round_trip():
    token = create_refresh_token("user-456")
    payload = decode_token(token)
    assert payload is not None
    assert payload["sub"] == "user-456"
    assert payload["type"] == "refresh"


def test_decode_invalid_token_returns_none():
    assert decode_token("not.a.valid.token") is None


def test_long_password_does_not_crash():
    """bcrypt has a 72-byte limit; we truncate rather than error."""
    very_long_password = "a" * 200
    hashed = hash_password(very_long_password)
    assert verify_password(very_long_password, hashed) is True
