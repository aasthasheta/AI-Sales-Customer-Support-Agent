import pytest


@pytest.mark.asyncio
async def test_signup_success(client):
    response = await client.post(
        "/api/v1/auth/signup",
        json={"email": "alice@example.com", "full_name": "Alice", "password": "password123"},
    )
    assert response.status_code == 201
    data = response.json()
    assert "access_token" in data
    assert "refresh_token" in data


@pytest.mark.asyncio
async def test_signup_duplicate_email_rejected(client):
    payload = {"email": "bob@example.com", "full_name": "Bob", "password": "password123"}
    r1 = await client.post("/api/v1/auth/signup", json=payload)
    assert r1.status_code == 201

    r2 = await client.post("/api/v1/auth/signup", json=payload)
    assert r2.status_code == 409


@pytest.mark.asyncio
async def test_signup_weak_password_rejected(client):
    response = await client.post(
        "/api/v1/auth/signup",
        json={"email": "weak@example.com", "full_name": "Weak", "password": "short"},
    )
    assert response.status_code == 422


@pytest.mark.asyncio
async def test_login_success(client):
    signup_payload = {"email": "carol@example.com", "full_name": "Carol", "password": "password123"}
    await client.post("/api/v1/auth/signup", json=signup_payload)

    response = await client.post(
        "/api/v1/auth/login", json={"email": "carol@example.com", "password": "password123"}
    )
    assert response.status_code == 200
    assert "access_token" in response.json()


@pytest.mark.asyncio
async def test_login_wrong_password(client):
    signup_payload = {"email": "dave@example.com", "full_name": "Dave", "password": "password123"}
    await client.post("/api/v1/auth/signup", json=signup_payload)

    response = await client.post(
        "/api/v1/auth/login", json={"email": "dave@example.com", "password": "wrongpass"}
    )
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_login_nonexistent_user(client):
    response = await client.post(
        "/api/v1/auth/login", json={"email": "nobody@example.com", "password": "password123"}
    )
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_me_requires_auth(client):
    response = await client.get("/api/v1/auth/me")
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_me_with_valid_token(client):
    signup_payload = {"email": "erin@example.com", "full_name": "Erin", "password": "password123"}
    signup_resp = await client.post("/api/v1/auth/signup", json=signup_payload)
    token = signup_resp.json()["access_token"]

    response = await client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    assert response.json()["email"] == "erin@example.com"


@pytest.mark.asyncio
async def test_refresh_token_flow(client):
    signup_payload = {"email": "frank@example.com", "full_name": "Frank", "password": "password123"}
    signup_resp = await client.post("/api/v1/auth/signup", json=signup_payload)
    refresh_token = signup_resp.json()["refresh_token"]

    response = await client.post("/api/v1/auth/refresh", json={"refresh_token": refresh_token})
    assert response.status_code == 200
    assert "access_token" in response.json()


@pytest.mark.asyncio
async def test_refresh_with_access_token_rejected(client):
    """Using an access token where a refresh token is expected should fail."""
    signup_payload = {"email": "grace@example.com", "full_name": "Grace", "password": "password123"}
    signup_resp = await client.post("/api/v1/auth/signup", json=signup_payload)
    access_token = signup_resp.json()["access_token"]

    response = await client.post("/api/v1/auth/refresh", json={"refresh_token": access_token})
    assert response.status_code == 401
