from app.rag.chunking import chunk_text


def test_chunk_text_empty_string():
    assert chunk_text("") == []


def test_chunk_text_short_text_single_chunk():
    text = "This is a short piece of text."
    chunks = chunk_text(text, chunk_size=800)
    assert len(chunks) == 1
    assert chunks[0] == text


def test_chunk_text_long_text_multiple_chunks():
    text = " ".join(["word"] * 500)  # ~2500 chars
    chunks = chunk_text(text, chunk_size=800, overlap=150)
    assert len(chunks) > 1


def test_chunk_text_no_word_cut_off():
    text = " ".join([f"word{i}" for i in range(300)])
    chunks = chunk_text(text, chunk_size=500, overlap=50)
    for chunk in chunks:
        # every chunk should start and end on whitespace boundaries (no partial "word12" -> "word1")
        assert not chunk.startswith(" ")
        assert not chunk.endswith(" ")


def test_chunk_text_overlap_present():
    text = " ".join([f"tok{i}" for i in range(200)])
    chunks = chunk_text(text, chunk_size=300, overlap=100)
    if len(chunks) > 1:
        # some tail of chunk[0] should reappear at the head of chunk[1]
        tail_words = set(chunks[0].split()[-5:])
        head_words = set(chunks[1].split()[:15])
        assert tail_words & head_words
