import uuid
from datetime import datetime

from pydantic import BaseModel

from app.models.order import OrderStatus


class OrderResponse(BaseModel):
    id: uuid.UUID
    order_number: str
    product_name: str
    quantity: int
    total_amount: float
    status: OrderStatus
    tracking_number: str | None
    estimated_delivery: datetime | None
    created_at: datetime

    model_config = {"from_attributes": True}


class OrderCancelRequest(BaseModel):
    order_number: str
    reason: str | None = None


class OrderReturnRequest(BaseModel):
    order_number: str
    reason: str
