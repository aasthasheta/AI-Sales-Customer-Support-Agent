from pydantic import BaseModel


class TopItem(BaseModel):
    label: str
    count: int


class AnalyticsSummary(BaseModel):
    total_users: int
    total_conversations: int
    total_messages: int
    total_orders: int
    avg_response_time_ms: float
    customer_satisfaction: float  # 0-5 average feedback rating
    top_searched_products: list[TopItem]
    most_asked_questions: list[TopItem]
    agent_usage_breakdown: list[TopItem]
