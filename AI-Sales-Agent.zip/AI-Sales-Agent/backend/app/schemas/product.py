import uuid

from pydantic import BaseModel, Field


class ProductResponse(BaseModel):
    id: uuid.UUID
    sku: str
    name: str
    description: str
    category: str
    price: float
    stock: int
    rating: float
    sales_count: int
    image_url: str | None

    model_config = {"from_attributes": True}


class RecommendRequest(BaseModel):
    query: str
    category: str | None = None
    min_price: float | None = Field(default=None, ge=0)
    max_price: float | None = Field(default=None, ge=0)
    top_k: int = Field(default=5, ge=1, le=20)


class RecommendResponse(BaseModel):
    products: list[ProductResponse]
    reasoning: str
