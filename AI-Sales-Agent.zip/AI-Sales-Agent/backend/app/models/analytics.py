import uuid
from datetime import datetime

from sqlalchemy import DateTime, Float, JSON, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.database.session import Base


class AnalyticsEvent(Base):
    """
    Generic event log used to power the analytics dashboard:
    top searched products, most asked questions, avg response time, CSAT, etc.

    Uses the cross-dialect `JSON` type (renders as native `jsonb` on Postgres,
    `JSON` on SQLite) so the same models work in tests without a live Postgres.
    """
    __tablename__ = "analytics_events"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    event_type: Mapped[str] = mapped_column(String(50), index=True, nullable=False)
    # e.g. "chat_query", "product_search", "response_time", "order_lookup"
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    response_time_ms: Mapped[float | None] = mapped_column(Float, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )
