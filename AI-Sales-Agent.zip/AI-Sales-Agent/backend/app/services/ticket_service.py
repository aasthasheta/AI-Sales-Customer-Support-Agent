import uuid

from app.database.session import AsyncSessionLocal
from app.models.feedback import SupportTicket, TicketPriority


async def create_ticket_for_user(
    user_id: str | None,
    subject: str,
    description: str,
    reason: str,
) -> SupportTicket | None:
    if user_id is None:
        return None

    priority = TicketPriority.HIGH if reason == "angry_user_detected" else TicketPriority.MEDIUM

    async with AsyncSessionLocal() as db:
        ticket = SupportTicket(
            user_id=uuid.UUID(user_id),
            subject=subject,
            description=description,
            reason=reason,
            priority=priority,
        )
        db.add(ticket)
        await db.commit()
        await db.refresh(ticket)
        return ticket
