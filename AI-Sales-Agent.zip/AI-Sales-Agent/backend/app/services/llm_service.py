"""
Thin, provider-agnostic LLM wrapper so agents don't care whether
OPENAI or GEMINI is configured. Switch via LLM_PROVIDER env var.
"""
from langchain_core.language_models.chat_models import BaseChatModel

from app.core.config import settings


def get_chat_model(temperature: float = 0.3) -> BaseChatModel:
    if settings.LLM_PROVIDER == "gemini":
        from langchain_google_genai import ChatGoogleGenerativeAI

        return ChatGoogleGenerativeAI(
            model=settings.GEMINI_MODEL,
            google_api_key=settings.GEMINI_API_KEY,
            temperature=temperature,
        )

    # default: openai
    from langchain_openai import ChatOpenAI

    return ChatOpenAI(
        model=settings.OPENAI_MODEL,
        api_key=settings.OPENAI_API_KEY,
        temperature=temperature,
        streaming=True,
    )
