"""
Semantic product recommendation using sentence-transformer embeddings.
Embeddings are computed lazily and cached in-process; for large catalogs
this would move to a proper vector index (Chroma collection), but for
the product catalog size this SaaS targets, in-memory cosine similarity
is fast and avoids an extra moving part.
"""
import numpy as np
from sqlalchemy import select

from app.database.session import AsyncSessionLocal
from app.embeddings.embedder import embed_texts
from app.models.product import Product

_cache: dict[str, tuple[list[Product], np.ndarray]] = {}


async def _get_catalog_embeddings() -> tuple[list[Product], np.ndarray]:
    if "catalog" in _cache:
        return _cache["catalog"]

    async with AsyncSessionLocal() as db:
        result = await db.execute(select(Product))
        products = list(result.scalars().all())

    if not products:
        _cache["catalog"] = ([], np.zeros((0, 384)))
        return _cache["catalog"]

    texts = [f"{p.name} {p.category} {p.description}" for p in products]
    vectors = embed_texts(texts)
    _cache["catalog"] = (products, vectors)
    return _cache["catalog"]


def invalidate_catalog_cache() -> None:
    _cache.pop("catalog", None)


async def semantic_product_search(
    query: str,
    top_k: int = 5,
    category: str | None = None,
    min_price: float | None = None,
    max_price: float | None = None,
) -> list[Product]:
    products, vectors = await _get_catalog_embeddings()
    if not products:
        return []

    query_vec = embed_texts([query])[0]
    norms = np.linalg.norm(vectors, axis=1) * np.linalg.norm(query_vec)
    norms[norms == 0] = 1e-8
    scores = (vectors @ query_vec) / norms

    ranked_indices = np.argsort(-scores)

    results: list[Product] = []
    for idx in ranked_indices:
        product = products[idx]
        if category and category.lower() not in product.category.lower():
            continue
        if min_price is not None and product.price < min_price:
            continue
        if max_price is not None and product.price > max_price:
            continue
        results.append(product)
        if len(results) >= top_k:
            break

    return results
