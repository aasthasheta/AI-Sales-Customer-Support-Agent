from sqlalchemy import select

from app.database.session import AsyncSessionLocal
from app.models.product import Product


async def search_products_by_keyword(query: str, limit: int = 5) -> list[Product]:
    """
    Simple ILIKE-based keyword search across name/category/description.
    Used by the Sales agent to ground pricing answers in real catalog data.
    """
    keywords = [w for w in query.split() if len(w) > 2][:5]
    if not keywords:
        return []

    async with AsyncSessionLocal() as db:
        stmt = select(Product)
        conditions = [
            Product.name.ilike(f"%{kw}%")
            | Product.category.ilike(f"%{kw}%")
            | Product.description.ilike(f"%{kw}%")
            for kw in keywords
        ]
        from sqlalchemy import or_

        stmt = stmt.where(or_(*conditions)).limit(limit)
        result = await db.execute(stmt)
        return list(result.scalars().all())


async def list_products(
    category: str | None = None,
    min_price: float | None = None,
    max_price: float | None = None,
    limit: int = 50,
) -> list[Product]:
    async with AsyncSessionLocal() as db:
        stmt = select(Product)
        if category:
            stmt = stmt.where(Product.category.ilike(f"%{category}%"))
        if min_price is not None:
            stmt = stmt.where(Product.price >= min_price)
        if max_price is not None:
            stmt = stmt.where(Product.price <= max_price)
        stmt = stmt.limit(limit)
        result = await db.execute(stmt)
        return list(result.scalars().all())
