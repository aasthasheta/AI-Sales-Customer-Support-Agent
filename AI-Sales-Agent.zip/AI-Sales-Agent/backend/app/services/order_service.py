from sqlalchemy import select

from app.database.session import AsyncSessionLocal
from app.models.order import Order, OrderStatus


async def get_order_by_number(order_number: str) -> Order | None:
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(Order).where(Order.order_number == order_number))
        return result.scalar_one_or_none()


async def cancel_order(order_number: str) -> Order | None:
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(Order).where(Order.order_number == order_number))
        order = result.scalar_one_or_none()
        if order is None:
            return None
        if order.status in (OrderStatus.DELIVERED, OrderStatus.CANCELLED, OrderStatus.RETURNED):
            return order  # cannot cancel; caller inspects status
        order.status = OrderStatus.CANCELLED
        await db.commit()
        await db.refresh(order)
        return order


async def return_order(order_number: str) -> Order | None:
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(Order).where(Order.order_number == order_number))
        order = result.scalar_one_or_none()
        if order is None:
            return None
        if order.status != OrderStatus.DELIVERED:
            return order  # only delivered orders can be returned; caller inspects status
        order.status = OrderStatus.RETURNED
        await db.commit()
        await db.refresh(order)
        return order
