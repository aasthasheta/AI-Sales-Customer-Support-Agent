"""
Full ingestion pipeline for an uploaded document:
extract text -> chunk -> embed -> store in ChromaDB -> update Document row.
"""
import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from app.embeddings.embedder import embed_texts
from app.models.document import Document, DocumentStatus
from app.rag.chroma_client import get_collection
from app.rag.chunking import chunk_text
from app.rag.extractors import extract_text


async def ingest_document(db: AsyncSession, document: Document) -> None:
    try:
        raw_text = extract_text(document.file_path, document.file_type)
        chunks = chunk_text(raw_text)

        if not chunks:
            document.status = DocumentStatus.FAILED
            document.chunk_count = 0
            await db.commit()
            return

        vectors = embed_texts(chunks)
        collection = get_collection()

        ids = [f"{document.id}-{i}" for i in range(len(chunks))]
        metadatas = [
            {"document_id": str(document.id), "document_name": document.filename, "chunk_index": i}
            for i in range(len(chunks))
        ]

        collection.add(
            ids=ids,
            embeddings=vectors.tolist(),
            documents=chunks,
            metadatas=metadatas,
        )

        document.status = DocumentStatus.INDEXED
        document.chunk_count = len(chunks)
        await db.commit()

    except Exception:
        document.status = DocumentStatus.FAILED
        await db.commit()
        raise
