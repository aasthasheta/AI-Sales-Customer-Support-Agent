"""
Retrieves the top-k most relevant document chunks for a query.
"""
from app.embeddings.embedder import embed_text
from app.rag.chroma_client import get_collection


async def retrieve_relevant_chunks(query: str, top_k: int = 4) -> list[dict]:
    collection = get_collection()
    if collection.count() == 0:
        return []

    query_vector = embed_text(query)
    results = collection.query(
        query_embeddings=[query_vector.tolist()],
        n_results=min(top_k, collection.count()),
    )

    chunks: list[dict] = []
    documents = results.get("documents", [[]])[0]
    metadatas = results.get("metadatas", [[]])[0]
    distances = results.get("distances", [[]])[0]

    for text, meta, distance in zip(documents, metadatas, distances):
        chunks.append(
            {
                "text": text,
                "document_name": meta.get("document_name", "unknown"),
                "score": round(1 - distance, 4),  # cosine distance -> similarity
            }
        )

    return chunks
