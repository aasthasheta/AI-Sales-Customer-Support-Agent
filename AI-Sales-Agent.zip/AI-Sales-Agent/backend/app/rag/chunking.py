"""
Text chunking with overlap for RAG ingestion.
"""


def chunk_text(text: str, chunk_size: int = 800, overlap: int = 150) -> list[str]:
    """
    Splits text into overlapping chunks on whitespace boundaries so we
    don't cut words in half. chunk_size/overlap are measured in characters.
    """
    text = " ".join(text.split())  # normalize whitespace
    if not text:
        return []

    chunks: list[str] = []
    start = 0
    text_len = len(text)

    while start < text_len:
        end = min(start + chunk_size, text_len)

        # extend to the next whitespace so we don't cut a word
        if end < text_len:
            next_space = text.find(" ", end)
            if next_space != -1 and next_space - end < 100:
                end = next_space

        chunks.append(text[start:end].strip())
        if end >= text_len:
            break
        start = max(end - overlap, start + 1)

    return [c for c in chunks if c]
