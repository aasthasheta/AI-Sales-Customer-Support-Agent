"""
Seeds the database with demo data: an admin user, a demo customer,
a product catalog, and a handful of orders in various states.

Run with:  python -m app.seed
"""
import asyncio
import csv
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

from app.core.security import hash_password
from app.database.session import AsyncSessionLocal, Base, engine
from app.models.order import Order, OrderStatus
from app.models.product import Product
from app.models.user import User

DEMO_ADMIN_EMAIL = "admin@aisalesagent.com"
DEMO_ADMIN_PASSWORD = "AdminPass123!"
DEMO_CUSTOMER_EMAIL = "customer@example.com"
DEMO_CUSTOMER_PASSWORD = "CustomerPass123!"


async def seed_users(session) -> tuple[User, User]:
    admin = User(
        email=DEMO_ADMIN_EMAIL,
        full_name="Admin User",
        hashed_password=hash_password(DEMO_ADMIN_PASSWORD),
        is_admin=True,
    )
    customer = User(
        email=DEMO_CUSTOMER_EMAIL,
        full_name="Demo Customer",
        hashed_password=hash_password(DEMO_CUSTOMER_PASSWORD),
        is_admin=False,
    )
    session.add_all([admin, customer])
    await session.commit()
    await session.refresh(admin)
    await session.refresh(customer)
    return admin, customer


async def seed_products(session) -> list[Product]:
    # app/seed.py -> app/ -> backend/ -> AI-Sales-Agent/ -> scripts/sample_products.csv
    csv_path = Path(__file__).resolve().parent.parent.parent / "scripts" / "sample_products.csv"
    products: list[Product] = []

    if csv_path.exists():
        with open(csv_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                products.append(
                    Product(
                        sku=row["sku"],
                        name=row["name"],
                        description=row["description"],
                        category=row["category"],
                        price=float(row["price"]),
                        stock=int(row["stock"]),
                        rating=float(row["rating"]),
                        sales_count=int(row["sales_count"]),
                        image_url=row.get("image_url") or None,
                    )
                )
    session.add_all(products)
    await session.commit()
    return products


async def seed_orders(session, customer: User, products: list[Product]) -> None:
    statuses = list(OrderStatus)
    orders = []
    for i in range(6):
        product = random.choice(products) if products else None
        status = statuses[i % len(statuses)]
        orders.append(
            Order(
                order_number=f"ORD-{100000 + i}",
                user_id=customer.id,
                product_name=product.name if product else "Sample Product",
                quantity=random.randint(1, 3),
                total_amount=round((product.price if product else 49.99) * random.randint(1, 3), 2),
                status=status,
                tracking_number=f"TRK-{900000 + i}" if status != OrderStatus.PENDING else None,
                estimated_delivery=datetime.now(timezone.utc) + timedelta(days=random.randint(1, 10)),
            )
        )
    session.add_all(orders)
    await session.commit()


async def main() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with AsyncSessionLocal() as session:
        admin, customer = await seed_users(session)
        products = await seed_products(session)
        await seed_orders(session, customer, products)

    print("Seed complete.")
    print(f"  Admin login:    {DEMO_ADMIN_EMAIL} / {DEMO_ADMIN_PASSWORD}")
    print(f"  Customer login: {DEMO_CUSTOMER_EMAIL} / {DEMO_CUSTOMER_PASSWORD}")
    print(f"  Products seeded: {len(products)}")
    print("  Orders seeded: 6 (ORD-100000 .. ORD-100005)")


if __name__ == "__main__":
    asyncio.run(main())
