"""
Sentence-transformers embedding wrapper, shared by the RAG pipeline
and the semantic product recommendation service.
"""
from functools import lru_cache

import numpy as np
from sentence_transformers import SentenceTransformer

from app.core.config import settings


@lru_cache
def _get_model() -> SentenceTransformer:
    return SentenceTransformer(settings.EMBEDDING_MODEL)


def embed_texts(texts: list[str]) -> np.ndarray:
    model = _get_model()
    return np.array(model.encode(texts, normalize_embeddings=False, show_progress_bar=False))


def embed_text(text: str) -> np.ndarray:
    return embed_texts([text])[0]
