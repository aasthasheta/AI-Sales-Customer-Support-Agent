import json
import time
import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.graph import agent_graph
from app.core.deps import get_current_user
from app.database.session import get_db
from app.models.analytics import AnalyticsEvent
from app.models.conversation import Conversation, Message, MessageRole
from app.models.user import User
from app.schemas.chat import (
    ChatRequest,
    ConversationResponse,
    FeedbackRequest,
    MessageReactionRequest,
)

router = APIRouter(tags=["Chat"])


async def _get_or_create_conversation(
    db: AsyncSession, user: User, conversation_id: uuid.UUID | None
) -> Conversation:
    if conversation_id:
        result = await db.execute(
            select(Conversation).where(
                Conversation.id == conversation_id, Conversation.user_id == user.id
            )
        )
        conversation = result.scalar_one_or_none()
        if conversation is None:
            raise HTTPException(status_code=404, detail="Conversation not found")
        return conversation

    conversation = Conversation(user_id=user.id, title="New Conversation")
    db.add(conversation)
    await db.commit()
    await db.refresh(conversation)
    return conversation


@router.post("/chat")
async def chat(
    payload: ChatRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Runs the message through the LangGraph multi-agent system and streams
    the response back as Server-Sent Events, then persists the exchange.
    """
    conversation = await _get_or_create_conversation(db, current_user, payload.conversation_id)

    history_result = await db.execute(
        select(Message).where(Message.conversation_id == conversation.id).order_by(Message.created_at)
    )
    history = [
        {"role": m.role.value, "content": m.content} for m in history_result.scalars().all()
    ]

    user_message = Message(
        conversation_id=conversation.id, role=MessageRole.USER, content=payload.message
    )
    db.add(user_message)
    await db.commit()

    if conversation.title == "New Conversation":
        conversation.title = payload.message[:60]
        await db.commit()

    start_time = time.perf_counter()
    final_state = await agent_graph.ainvoke(
        {
            "user_message": payload.message,
            "user_id": str(current_user.id),
            "conversation_history": history,
        }
    )
    elapsed_ms = (time.perf_counter() - start_time) * 1000

    assistant_message = Message(
        conversation_id=conversation.id,
        role=MessageRole.ASSISTANT,
        content=final_state["response"],
        agent_used=final_state["agent_used"],
        sources=json.dumps(final_state.get("sources", [])),
    )
    db.add(assistant_message)

    db.add(
        AnalyticsEvent(
            event_type="chat_query",
            payload={
                "agent_used": final_state["agent_used"],
                "query": payload.message[:200],
                "escalated": final_state.get("escalated", False),
            },
            response_time_ms=elapsed_ms,
        )
    )
    await db.commit()
    await db.refresh(assistant_message)

    async def event_stream():
        # Word-chunked streaming for a ChatGPT-style typing effect on the frontend.
        words = final_state["response"].split(" ")
        for i, word in enumerate(words):
            chunk = word + (" " if i < len(words) - 1 else "")
            yield f"data: {json.dumps({'type': 'token', 'content': chunk})}\n\n"

        final_payload = {
            "type": "done",
            "conversation_id": str(conversation.id),
            "message_id": str(assistant_message.id),
            "agent_used": final_state["agent_used"],
            "sources": final_state.get("sources", []),
        }
        yield f"data: {json.dumps(final_payload)}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@router.get("/conversations", response_model=list[ConversationResponse])
async def list_conversations(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Conversation)
        .where(Conversation.user_id == current_user.id)
        .order_by(Conversation.updated_at.desc())
    )
    return result.scalars().all()


@router.get("/conversations/{conversation_id}", response_model=ConversationResponse)
async def get_conversation(
    conversation_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Conversation).where(
            Conversation.id == conversation_id, Conversation.user_id == current_user.id
        )
    )
    conversation = result.scalar_one_or_none()
    if conversation is None:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conversation


@router.post("/messages/{message_id}/reaction")
async def react_to_message(
    message_id: uuid.UUID,
    payload: MessageReactionRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Message).where(Message.id == message_id))
    message = result.scalar_one_or_none()
    if message is None:
        raise HTTPException(status_code=404, detail="Message not found")

    message.liked = payload.liked
    await db.commit()
    return {"status": "ok"}


@router.post("/feedback", status_code=status.HTTP_201_CREATED)
async def submit_feedback(
    payload: FeedbackRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.models.feedback import Feedback

    feedback = Feedback(
        user_id=current_user.id,
        conversation_id=payload.conversation_id,
        rating=payload.rating,
        comment=payload.comment,
    )
    db.add(feedback)
    await db.commit()
    return {"status": "ok"}
