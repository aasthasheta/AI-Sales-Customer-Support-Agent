from collections import Counter

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import get_current_admin
from app.database.session import get_db
from app.models.analytics import AnalyticsEvent
from app.models.conversation import Conversation, Message
from app.models.feedback import Feedback
from app.models.order import Order
from app.models.user import User
from app.schemas.analytics import AnalyticsSummary, TopItem

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("", response_model=AnalyticsSummary)
async def get_analytics(
    current_admin: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    total_users = (await db.execute(select(func.count(User.id)))).scalar_one()
    total_conversations = (await db.execute(select(func.count(Conversation.id)))).scalar_one()
    total_messages = (await db.execute(select(func.count(Message.id)))).scalar_one()
    total_orders = (await db.execute(select(func.count(Order.id)))).scalar_one()

    avg_response_time = (
        await db.execute(select(func.avg(AnalyticsEvent.response_time_ms)))
    ).scalar_one() or 0.0

    avg_rating = (await db.execute(select(func.avg(Feedback.rating)))).scalar_one() or 0.0

    events_result = await db.execute(
        select(AnalyticsEvent.payload).where(AnalyticsEvent.event_type == "chat_query")
    )
    payloads = [row[0] for row in events_result.all()]

    query_counter = Counter(p.get("query", "").strip().lower() for p in payloads if p.get("query"))
    agent_counter = Counter(p.get("agent_used", "unknown") for p in payloads)

    return AnalyticsSummary(
        total_users=total_users,
        total_conversations=total_conversations,
        total_messages=total_messages,
        total_orders=total_orders,
        avg_response_time_ms=round(float(avg_response_time), 2),
        customer_satisfaction=round(float(avg_rating), 2),
        top_searched_products=[TopItem(label=q, count=c) for q, c in query_counter.most_common(10)],
        most_asked_questions=[TopItem(label=q, count=c) for q, c in query_counter.most_common(10)],
        agent_usage_breakdown=[TopItem(label=a, count=c) for a, c in agent_counter.most_common()],
    )
