from fastapi import APIRouter, Depends, HTTPException

from app.core.deps import get_current_user
from app.models.order import OrderStatus
from app.models.user import User
from app.schemas.order import OrderCancelRequest, OrderResponse, OrderReturnRequest
from app.services.order_service import cancel_order, get_order_by_number, return_order

router = APIRouter(prefix="/orders", tags=["Orders"])


@router.get("/{order_number}", response_model=OrderResponse)
async def get_order(order_number: str, current_user: User = Depends(get_current_user)):
    order = await get_order_by_number(order_number.upper())
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


@router.post("/cancel", response_model=OrderResponse)
async def cancel(payload: OrderCancelRequest, current_user: User = Depends(get_current_user)):
    order = await cancel_order(payload.order_number.upper())
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    if order.status != OrderStatus.CANCELLED:
        raise HTTPException(
            status_code=400,
            detail=f"Order cannot be cancelled — current status is '{order.status.value}'",
        )
    return order


@router.post("/return", response_model=OrderResponse)
async def return_item(payload: OrderReturnRequest, current_user: User = Depends(get_current_user)):
    order = await return_order(payload.order_number.upper())
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    if order.status != OrderStatus.RETURNED:
        raise HTTPException(
            status_code=400,
            detail="Only delivered orders can be returned",
        )
    return order
