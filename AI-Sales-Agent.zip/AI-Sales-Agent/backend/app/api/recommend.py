from fastapi import APIRouter, Depends

from app.core.deps import get_current_user
from app.models.user import User
from app.schemas.product import RecommendRequest, RecommendResponse
from app.services.recommendation_service import semantic_product_search

router = APIRouter(prefix="/recommend", tags=["Recommendations"])


@router.post("", response_model=RecommendResponse)
async def recommend(payload: RecommendRequest, current_user: User = Depends(get_current_user)):
    products = await semantic_product_search(
        query=payload.query,
        top_k=payload.top_k,
        category=payload.category,
        min_price=payload.min_price,
        max_price=payload.max_price,
    )

    reasoning = (
        f"Found {len(products)} product(s) semantically matching '{payload.query}'"
        + (f" in category '{payload.category}'" if payload.category else "")
        + "."
    )

    return RecommendResponse(products=products, reasoning=reasoning)
