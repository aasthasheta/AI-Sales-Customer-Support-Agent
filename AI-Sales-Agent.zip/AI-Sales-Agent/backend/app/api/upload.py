import csv
import io
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.deps import get_current_admin
from app.database.session import get_db
from app.models.document import Document, DocumentStatus
from app.models.product import Product
from app.models.user import User
from app.rag.ingest import ingest_document
from app.services.recommendation_service import invalidate_catalog_cache

router = APIRouter(prefix="/upload", tags=["Admin Uploads"])

ALLOWED_DOC_TYPES = {"pdf", "docx", "txt"}


@router.post("/document", status_code=status.HTTP_201_CREATED)
async def upload_document(
    file: UploadFile = File(...),
    current_admin: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    file_ext = (file.filename.rsplit(".", 1)[-1] if "." in file.filename else "").lower()
    if file_ext not in ALLOWED_DOC_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{file_ext}'. Allowed: {', '.join(ALLOWED_DOC_TYPES)}",
        )

    upload_dir = Path(settings.UPLOAD_DIR)
    upload_dir.mkdir(parents=True, exist_ok=True)

    safe_name = f"{uuid.uuid4()}_{file.filename}"
    dest_path = upload_dir / safe_name

    contents = await file.read()
    if len(contents) > settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(status_code=413, detail="File too large")

    dest_path.write_bytes(contents)

    document = Document(
        filename=file.filename,
        file_type=file_ext,
        file_path=str(dest_path),
        status=DocumentStatus.PROCESSING,
    )
    db.add(document)
    await db.commit()
    await db.refresh(document)

    await ingest_document(db, document)

    return {
        "id": str(document.id),
        "filename": document.filename,
        "status": document.status.value,
        "chunk_count": document.chunk_count,
    }


@router.post("/products", status_code=status.HTTP_201_CREATED)
async def upload_products_csv(
    file: UploadFile = File(...),
    current_admin: User = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    """
    Bulk-imports products from a CSV with columns:
    sku,name,description,category,price,stock,rating,sales_count,image_url
    """
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="File must be a .csv")

    contents = await file.read()
    reader = csv.DictReader(io.StringIO(contents.decode("utf-8")))

    required_cols = {"sku", "name", "category", "price"}
    if not required_cols.issubset(set(reader.fieldnames or [])):
        raise HTTPException(
            status_code=400,
            detail=f"CSV must include columns: {', '.join(sorted(required_cols))}",
        )

    created, skipped = 0, 0
    for row in reader:
        try:
            product = Product(
                sku=row["sku"].strip(),
                name=row["name"].strip(),
                description=row.get("description", "").strip(),
                category=row["category"].strip(),
                price=float(row["price"]),
                stock=int(row.get("stock", 0) or 0),
                rating=float(row.get("rating", 0) or 0),
                sales_count=int(row.get("sales_count", 0) or 0),
                image_url=row.get("image_url") or None,
            )
            db.add(product)
            created += 1
        except (ValueError, KeyError):
            skipped += 1
            continue

    await db.commit()
    invalidate_catalog_cache()

    return {"created": created, "skipped": skipped}
